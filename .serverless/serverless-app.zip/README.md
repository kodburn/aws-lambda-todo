# AWS Lambda app

ToDo app made with a sole purpose to teach myself basics of AWS.

#### Recources
[egghead.io serverless course](https://egghead.io/courses/develop-a-serverless-backend-using-node-js-on-aws-lambda)

####Tech used:
- AWS Lambda
- AWS DynamoDB
- Serverless framework
